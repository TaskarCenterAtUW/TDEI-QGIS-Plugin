# Development

## Setup

1. Clone/copy into QGIS `python/plugins/tdei`
2. Enable **Plugin Reloader** (optional) for faster iteration
3. No virtualenv pip deps required for runtime

## Conventions

- Type hints on public APIs
- Business logic outside `ui/`
- User-facing strings via `self.tr(...)` where widgets inherit `QWidget`
- Log via `logging.logger.get_logger` — never log tokens/passwords

## Scripts

```bash
python3 scripts/build_plugin.py      # validate structure
python3 scripts/package_plugin.py    # write dist/tdei.zip
```

## Adding a feature

1. Add `features/<name>/service.py` (+ models if needed)
2. Register in `ServiceContainer` if it needs DI
3. Add `ui/<name>/page.py` and register in `MainWindow` navigation
4. Gate with `feature.<name>` in settings when useful

## Compatibility

Isolate QGIS/Qt differences in `core/compatibility/`. Prefer
`qgis.PyQt` imports (QGIS-supported), not raw `PyQt5`/`PyQt6`.
