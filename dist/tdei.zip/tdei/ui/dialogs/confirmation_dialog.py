# -*- coding: utf-8 -*-
"""Reusable confirmation dialog for destructive actions."""

from __future__ import annotations

from qgis.PyQt.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QLabel,
    QVBoxLayout,
)

from ...core.compatibility.qt_compat import DialogAccepted
from ..components import DangerButton, SecondaryButton


class ConfirmationDialog(QDialog):
    def __init__(
        self,
        title: str,
        message: str,
        *,
        confirm_text: str = "Confirm",
        destructive: bool = False,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        layout = QVBoxLayout(self)
        body = QLabel(message)
        body.setWordWrap(True)
        layout.addWidget(body)
        buttons = QDialogButtonBox()
        cancel = buttons.addButton(QDialogButtonBox.Cancel)
        if destructive:
            confirm = DangerButton(confirm_text)
            buttons.addButton(confirm, QDialogButtonBox.AcceptRole)
        else:
            confirm = buttons.addButton(confirm_text, QDialogButtonBox.AcceptRole)
        cancel.clicked.connect(self.reject)
        confirm.clicked.connect(self.accept)
        layout.addWidget(buttons)

    @staticmethod
    def ask(
        parent,
        title: str,
        message: str,
        *,
        confirm_text: str = "Confirm",
        destructive: bool = False,
    ) -> bool:
        dialog = ConfirmationDialog(
            title,
            message,
            confirm_text=confirm_text,
            destructive=destructive,
            parent=parent,
        )
        return dialog.exec_() == DialogAccepted
