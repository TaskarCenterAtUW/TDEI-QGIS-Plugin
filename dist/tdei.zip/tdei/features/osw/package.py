# -*- coding: utf-8 -*-
"""OSW zip extraction (no QGIS dependency)."""

from __future__ import annotations

import json
import os
import shutil
import zipfile
from typing import List

from ...core.exceptions import UnexpectedApiError, ValidationError

_GEOJSON_ORDER = ("nodes", "edges", "lines", "points", "polygons", "zones")


def unpack_osw_package(zip_path: str, dest_dir: str) -> List[str]:
    """Extract a TDEI OSW zip and return GeoJSON file paths."""
    if os.path.isdir(dest_dir):
        shutil.rmtree(dest_dir)
    os.makedirs(dest_dir, exist_ok=True)
    outer_dir = os.path.join(dest_dir, "outer")
    os.makedirs(outer_dir, exist_ok=True)
    _safe_extract(zip_path, outer_dir)

    geojsons = _find_geojsons(outer_dir)
    if geojsons:
        return _sort_geojsons(geojsons)

    inner_zips = _find_zips(outer_dir)
    if not inner_zips:
        raise UnexpectedApiError(
            "The OSW package has no GeoJSON files or inner zip."
        )

    inner_dir = os.path.join(dest_dir, "geojson")
    os.makedirs(inner_dir, exist_ok=True)
    for inner_zip in inner_zips:
        _safe_extract(inner_zip, inner_dir)

    geojsons = _find_geojsons(inner_dir)
    if not geojsons:
        raise UnexpectedApiError("No GeoJSON files found in the OSW package.")
    return _sort_geojsons(geojsons)


def zip_geojson_paths(paths: List[str], dest_zip: str) -> str:
    files = [path for path in paths if path and os.path.isfile(path)]
    if not files:
        raise ValidationError("No GeoJSON files to zip.")
    parent = os.path.dirname(dest_zip)
    if parent:
        os.makedirs(parent, exist_ok=True)
    used = set()
    with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            name = os.path.basename(path)
            stem, ext = os.path.splitext(name)
            candidate = name
            index = 2
            while candidate.lower() in used:
                candidate = "{}{}{}".format(stem, index, ext)
                index += 1
            used.add(candidate.lower())
            archive.write(path, candidate)
    return dest_zip


def assert_zip_bytes(data: bytes) -> None:
    if data[:2] != b"PK":
        raise UnexpectedApiError(_non_zip_message(data))


def _safe_extract(zip_path: str, dest_dir: str) -> None:
    dest_dir = os.path.abspath(dest_dir)
    with zipfile.ZipFile(zip_path, "r") as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            member = info.filename.replace("\\", "/")
            if member.startswith("/") or any(
                part == ".." for part in member.split("/")
            ):
                continue
            target = os.path.abspath(os.path.join(dest_dir, member))
            if not (
                target == dest_dir or target.startswith(dest_dir + os.sep)
            ):
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as out:
                out.write(source.read())


def _find_geojsons(root: str) -> List[str]:
    found = []
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            lower = name.lower()
            if lower == "metadata.json":
                continue
            if lower.endswith(".geojson"):
                found.append(os.path.join(dirpath, name))
    return found


def _find_zips(root: str) -> List[str]:
    found = []
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            if name.lower().endswith(".zip"):
                found.append(os.path.join(dirpath, name))
    return found


def _sort_geojsons(paths: List[str]) -> List[str]:
    def key(path: str):
        name = os.path.basename(path).lower()
        for index, token in enumerate(_GEOJSON_ORDER):
            if token in name:
                return (index, name)
        return (len(_GEOJSON_ORDER), name)

    return sorted(paths, key=key)


def _non_zip_message(data: bytes) -> str:
    try:
        payload = json.loads(data.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return "Download did not return a zip file."
    if isinstance(payload, dict):
        for key in ("message", "error", "detail", "title"):
            value = payload.get(key)
            if value:
                return str(value)
    return "Download did not return a zip file."
