# -*- coding: utf-8 -*-
"""Thin QgsProject wrapper."""

from __future__ import annotations

from qgis.core import QgsProject


class ProjectManager:
    def instance(self) -> QgsProject:
        return QgsProject.instance()
