# -*- coding: utf-8 -*-
"""Compiled Qt stylesheets from theme tokens."""

from __future__ import annotations

from . import colors, dimensions, typography


def application_stylesheet() -> str:
    return """
        QWidget#TdeiMainWindow {{
            background-color: {bg};
            color: {text};
            font-family: {font};
            font-size: {fs}px;
        }}
        QWidget#AppHeader {{
            background-color: {primary};
            min-height: {header}px;
            max-height: {header}px;
        }}
        QLabel#HeaderTitle {{
            color: {on_primary};
            font-size: {fs_lg}px;
            font-weight: {fw_semi};
        }}
        QLabel#HeaderUser {{
            color: {on_primary};
            font-size: {fs_sm}px;
        }}
        QPushButton#HeaderLogout {{
            color: {on_primary};
            background: transparent;
            border: 1px solid rgba(255,255,255,0.45);
            border-radius: {radius}px;
            padding: 4px 12px;
        }}
        QPushButton#HeaderLogout:hover {{
            background: rgba(255,255,255,0.12);
        }}
        QWidget#Sidebar {{
            background-color: {surface};
            border-right: 1px solid {border};
            min-width: {sidebar}px;
            max-width: {sidebar}px;
        }}
        QPushButton.NavItem {{
            text-align: left;
            padding: 10px 14px;
            border: none;
            border-radius: {radius}px;
            color: {text};
            background: transparent;
            font-size: {fs_md}px;
        }}
        QPushButton.NavItem:hover {{
            background-color: {surface_alt};
        }}
        QPushButton.NavItem[active="true"] {{
            background-color: {primary};
            color: {on_primary};
            font-weight: {fw_semi};
        }}
        QWidget#PageContainer {{
            background-color: {bg};
        }}
        QPushButton#PrimaryButton {{
            min-height: {ctrl}px;
            padding: 6px 14px;
            color: {on_primary};
            background-color: {primary};
            border: 1px solid {primary};
            border-radius: {radius}px;
            font-size: {fs_lg}px;
            font-weight: {fw_semi};
        }}
        QPushButton#PrimaryButton:hover {{
            background-color: {primary_hover};
        }}
        QPushButton#PrimaryButton:disabled {{
            background-color: {disabled};
            border-color: {disabled};
            color: {disabled_text};
        }}
        QPushButton#SecondaryButton {{
            min-height: {ctrl}px;
            padding: 6px 14px;
            color: {primary};
            background-color: {surface};
            border: 1px solid {primary};
            border-radius: {radius}px;
        }}
        QPushButton#SecondaryButton:hover {{
            background-color: {surface_alt};
        }}
        QPushButton#DangerButton {{
            min-height: {ctrl}px;
            padding: 6px 14px;
            color: #ffffff;
            background-color: {error};
            border: 1px solid {error};
            border-radius: {radius}px;
        }}
        QFrame#EmptyState, QFrame#ErrorState {{
            background-color: {surface};
            border: 1px solid {border};
            border-radius: {radius_lg}px;
            padding: 24px;
        }}
        QLabel#EmptyTitle, QLabel#ErrorTitle {{
            font-size: {fs_xl}px;
            font-weight: {fw_semi};
            color: {text};
        }}
        QLabel#EmptyBody, QLabel#ErrorBody {{
            color: {muted};
            font-size: {fs_md}px;
        }}
        QStatusBar {{
            background: {surface};
            color: {muted};
        }}
        QTableWidget {{
            background: {surface};
            border: 1px solid {border};
            gridline-color: {border};
        }}
        QHeaderView::section {{
            background: {surface_alt};
            padding: 6px;
            border: none;
            border-bottom: 1px solid {border};
            font-weight: {fw_semi};
        }}
        QLineEdit, QComboBox {{
            min-height: {ctrl}px;
            padding: 4px 10px;
            border: 1px solid {border};
            border-radius: {radius}px;
            background: {surface};
        }}
        QLineEdit:focus, QComboBox:focus {{
            border: 1px solid {focus};
        }}
    """.format(
        bg=colors.BACKGROUND,
        text=colors.TEXT,
        muted=colors.TEXT_MUTED,
        font=typography.FONT_FAMILY,
        fs=typography.FONT_SIZE_MD,
        fs_sm=typography.FONT_SIZE_SM,
        fs_md=typography.FONT_SIZE_MD,
        fs_lg=typography.FONT_SIZE_LG,
        fs_xl=typography.FONT_SIZE_XL,
        fw_semi=typography.FONT_WEIGHT_SEMIBOLD,
        primary=colors.PRIMARY,
        primary_hover=colors.PRIMARY_HOVER,
        on_primary=colors.TEXT_ON_PRIMARY,
        surface=colors.SURFACE,
        surface_alt=colors.SURFACE_ALT,
        border=colors.BORDER,
        header=dimensions.HEADER_HEIGHT,
        sidebar=dimensions.SIDEBAR_WIDTH,
        radius=dimensions.RADIUS_MD,
        radius_lg=dimensions.RADIUS_LG,
        ctrl=dimensions.CONTROL_HEIGHT,
        disabled=colors.DISABLED_BG,
        disabled_text=colors.DISABLED_TEXT,
        error=colors.ERROR,
        focus=colors.FOCUS,
    )


def login_stylesheet() -> str:
    return """
        QWidget#loginHeader {{
            background-color: {primary};
        }}
        QLabel#lblHeaderLogo {{
            background-color: #ffffff;
            border-radius: 4px;
            padding: 2px 6px;
        }}
        QFrame#loginCard {{
            background-color: #ffffff;
            border: 1px solid rgba(0, 0, 0, 0.176);
            border-radius: 6px;
        }}
        QLabel#lblTitle {{
            color: {text};
            font-size: 26px;
            font-weight: 300;
        }}
        QLabel#lblSubtitle {{
            color: {secondary};
            font-size: 14px;
        }}
        QLabel#lblUsername, QLabel#lblPassword {{
            color: {text};
            font-size: 16px;
        }}
        QLineEdit#txtUsername, QLineEdit#txtPassword {{
            min-height: 38px;
            padding: 6px 12px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            font-size: 16px;
        }}
        QLineEdit#txtUsername:focus, QLineEdit#txtPassword:focus {{
            border: 1px solid {primary};
        }}
        QPushButton#btnLogin {{
            min-height: 38px;
            color: #ffffff;
            background-color: {primary};
            border: 1px solid {primary};
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
        }}
        QPushButton#btnLogin:disabled {{
            background-color: #cccccc;
            border-color: #cccccc;
        }}
        QLabel#lblStatus {{
            color: {secondary};
            font-size: 14px;
        }}
        QLabel#lblVersion {{
            color: {secondary};
            font-size: 12px;
        }}
    """.format(
        primary=colors.PRIMARY,
        secondary=colors.SECONDARY,
        text=colors.TEXT,
    )
