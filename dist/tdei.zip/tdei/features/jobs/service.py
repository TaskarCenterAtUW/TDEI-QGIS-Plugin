# -*- coding: utf-8 -*-
"""OpenAPI-driven TDEI job definitions and request building."""

from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional
from urllib.parse import quote, urlencode

from ...config.environment import resolve_environment
from ...core.models import JobDefinition, JobField, JobSubmissionResult
from ...logging.logger import get_logger

if False:  # TYPE_CHECKING without circular import at runtime
    pass

LOG = get_logger(__name__)

SPEC_FILENAME = "tdei_jobs_spec.json"
_DATASET_FIELD_NAMES = (
    "tdei_dataset_id",
    "tdei_dataset_id_one",
    "tdei_dataset_id_two",
    "source_dataset_id",
    "target_dataset_id",
)


class JobService:
    def __init__(self, api_client, layer_manager, settings) -> None:
        self._api = api_client
        self._layers = layer_manager
        self._settings = settings
        self._spec: Optional[Dict[str, Any]] = None

    def list_jobs(self) -> List[JobDefinition]:
        spec = self._load_spec()
        jobs: List[JobDefinition] = []
        for path, methods in (spec.get("paths") or {}).items():
            operation = (methods or {}).get("post")
            if not operation:
                continue
            jobs.append(
                JobDefinition(
                    title=operation.get("summary")
                    or operation.get("operationId")
                    or path,
                    path=path,
                    method="POST",
                    operation=operation,
                )
            )
        jobs.sort(key=lambda item: item.title.lower())
        return jobs

    def form_fields(
        self, job: JobDefinition, dataset_id: Optional[str] = None
    ) -> List[JobField]:
        spec = self._load_spec()
        operation = job.operation
        fields: List[JobField] = []
        for param in operation.get("parameters") or []:
            param = resolve_ref(param, spec)
            if param.get("in") == "path":
                continue
            schema = resolve_ref(param.get("schema") or {}, spec)
            fields.append(
                _field_from_schema(
                    name=param.get("name"),
                    location=param.get("in") or "query",
                    schema=schema,
                    required=bool(param.get("required")),
                    description=param.get("description")
                    or schema.get("description")
                    or "",
                    spec=spec,
                )
            )
        body = operation.get("requestBody")
        if body:
            body = resolve_ref(body, spec)
            content = body.get("content") or {}
            if "application/json" in content:
                schema = resolve_ref(
                    content["application/json"].get("schema") or {}, spec
                )
                required = set(schema.get("required") or [])
                for name, prop in (schema.get("properties") or {}).items():
                    prop = resolve_ref(prop, spec)
                    fields.append(
                        _field_from_schema(
                            name=name,
                            location="json",
                            schema=prop,
                            required=name in required,
                            description=prop.get("description") or "",
                            spec=spec,
                        )
                    )
            elif "multipart/form-data" in content:
                schema = resolve_ref(
                    content["multipart/form-data"].get("schema") or {}, spec
                )
                required = set(schema.get("required") or [])
                for name, prop in (schema.get("properties") or {}).items():
                    prop = resolve_ref(prop, spec)
                    fields.append(
                        _field_from_schema(
                            name=name,
                            location="form",
                            schema=prop,
                            required=name in required,
                            description=prop.get("description") or "",
                            spec=spec,
                        )
                    )
        if dataset_id:
            for field in fields:
                if field.name in _DATASET_FIELD_NAMES:
                    field.value = dataset_id
        return fields

    def build_request(
        self,
        job: JobDefinition,
        fields: List[JobField],
        values: Dict[str, Any],
        dataset_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        env = resolve_environment(self._settings)
        path = job.path
        path_params = re.findall(r"\{([^}]+)\}", path)
        for name in path_params:
            path = path.replace(
                "{" + name + "}",
                quote(str(values.get(name) or dataset_id or ""), safe=""),
            )
        # Host without /api/v1 suffix for OpenAPI paths that include /api/v1
        host = env.api_base_url
        if host.endswith("/api/v1"):
            host = host[: -len("/api/v1")]
        url = host + path
        query = []
        json_body: Dict[str, Any] = {}
        form_fields_out: Dict[str, Any] = {}
        files: Dict[str, str] = {}
        has_json = False
        has_form = False
        for field in fields:
            name = field.name
            value = values.get(name)
            location = field.location
            if location == "query":
                if value in (None, ""):
                    if field.required:
                        raise ValueError("{} is required".format(name))
                    continue
                if field.type == "array" and isinstance(value, str):
                    value = [
                        part.strip()
                        for part in value.split(",")
                        if part.strip()
                    ]
                if isinstance(value, list):
                    for item in value:
                        query.append((name, item))
                else:
                    query.append((name, value))
            elif location == "json":
                has_json = True
                if value in (None, ""):
                    if field.required:
                        raise ValueError("{} is required".format(name))
                    continue
                json_body[name] = _coerce(field, value)
            elif location == "form":
                has_form = True
                if field.format == "binary":
                    if not value and field.required:
                        raise ValueError("{} is required".format(name))
                    if value:
                        files[name] = value
                else:
                    if value in (None, "") and field.required:
                        raise ValueError("{} is required".format(name))
                    if value not in (None, ""):
                        form_fields_out[name] = value
        if query:
            url = "{}?{}".format(url, urlencode(query, doseq=True))
        return {
            "url": url,
            "json_body": json_body if has_json else None,
            "fields": form_fields_out if has_form else None,
            "files": files if has_form else None,
        }

    def submit(
        self,
        job: JobDefinition,
        fields: List[JobField],
        values: Dict[str, Any],
        dataset_id: Optional[str] = None,
    ) -> JobSubmissionResult:
        request = self.build_request(job, fields, values, dataset_id=dataset_id)
        if request["files"] or request["fields"]:
            raw = self._api.post_multipart(
                request["url"],
                fields=request["fields"],
                files=request["files"],
            )
        else:
            raw = self._api.post_json_url(
                request["url"], request["json_body"]
            )
        job_id = str(
            raw.get("job_id") or raw.get("jobId") or raw.get("id") or ""
        )
        return JobSubmissionResult(
            job_id=job_id,
            location=str(raw.get("location") or ""),
            raw=raw,
        )

    def is_osw_package_field(self, field: JobField) -> bool:
        if field.format != "binary":
            return False
        if field.name == "dataset":
            return True
        description = (field.description or "").lower()
        return "zip" in description and (
            "geojson" in description or "osw dataset" in description
        )

    def prepare_osw_upload(self, dataset_id: str) -> str:
        return self._layers.prepare_osw_package_zip(dataset_id)

    def _load_spec(self) -> Dict[str, Any]:
        if self._spec is not None:
            return self._spec
        root = os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        )
        path = os.path.join(root, SPEC_FILENAME)
        with open(path) as handle:
            self._spec = json.load(handle)
        return self._spec


def resolve_ref(node: Any, spec: Dict[str, Any]) -> Any:
    if not isinstance(node, dict) or "$ref" not in node:
        return node
    pointer = node["$ref"].lstrip("#/").split("/")
    resolved: Any = spec
    for part in pointer:
        resolved = resolved[part]
    return resolved


def _field_from_schema(
    name, location, schema, required, description, spec
) -> JobField:
    schema = resolve_ref(schema, spec)
    default = schema.get("default")
    return JobField(
        name=name,
        location=location,
        required=required,
        type=schema.get("type") or "string",
        format=schema.get("format"),
        enum=schema.get("enum"),
        description=description or schema.get("description") or "",
        value="" if default is None else default,
    )


def _coerce(field: JobField, value: Any) -> Any:
    if field.type == "number":
        return float(value)
    if field.type == "integer":
        return int(value)
    if field.type == "boolean":
        return bool(value)
    if field.type == "array" and isinstance(value, str):
        text = value.strip()
        if text.startswith("["):
            return json.loads(text)
        return [part.strip() for part in text.split(",") if part.strip()]
    return value
