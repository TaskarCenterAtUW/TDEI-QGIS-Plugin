# -*- coding: utf-8 -*-
"""Dashboard landing page."""

from __future__ import annotations

from typing import TYPE_CHECKING

from qgis.PyQt.QtWidgets import QLabel, QVBoxLayout, QWidget

if TYPE_CHECKING:
    from ...core.services.container import ServiceContainer


class DashboardPage(QWidget):
    def __init__(self, container: "ServiceContainer", parent=None) -> None:
        super().__init__(parent)
        self._container = container
        layout = QVBoxLayout(self)
        title = QLabel(self.tr("Dashboard"))
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        env = container.environment()
        body = QLabel(
            self.tr(
                "Welcome to TDEI for QGIS.\n\n"
                "Environment: {env}\n"
                "API: {api}\n\n"
                "Use Datasets to browse and load OpenSidewalks layers.\n"
                "Right-click a loaded TDEI layer group to submit jobs."
            ).format(env=env.label, api=env.api_base_url)
        )
        body.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(body)
        layout.addStretch()
