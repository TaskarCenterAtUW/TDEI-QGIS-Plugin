# -*- coding: utf-8 -*-
"""Environment resolution for API endpoints."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .defaults import DEFAULT_ENVIRONMENT, ENVIRONMENTS

if TYPE_CHECKING:
    from .settings import SettingsManager


@dataclass(frozen=True)
class EnvironmentConfig:
    """Resolved runtime environment endpoints."""

    key: str
    label: str
    api_base_url: str
    auth_url: str
    portal_url: str


def resolve_environment(settings: "SettingsManager") -> EnvironmentConfig:
    """Build endpoint config from settings (dev / staging / prod / custom)."""
    key = settings.get("environment", DEFAULT_ENVIRONMENT)
    if key == "custom":
        base = (settings.get("custom_api_base_url") or "").rstrip("/")
        if not base:
            key = DEFAULT_ENVIRONMENT
            preset = ENVIRONMENTS[key]
            base = preset["api_base_url"]
            label = preset["label"]
            portal = preset["portal_url"]
            auth_path = preset["auth_path"]
        else:
            label = "Custom"
            portal = settings.get("custom_portal_url", "")
            auth_path = "/authenticate"
    else:
        if key not in ENVIRONMENTS:
            key = DEFAULT_ENVIRONMENT
        preset = ENVIRONMENTS[key]
        base = preset["api_base_url"]
        label = preset["label"]
        portal = preset["portal_url"]
        auth_path = preset["auth_path"]

    auth_url = "{}{}".format(base.rstrip("/"), auth_path)
    return EnvironmentConfig(
        key=key,
        label=label,
        api_base_url=base.rstrip("/"),
        auth_url=auth_url,
        portal_url=portal,
    )
