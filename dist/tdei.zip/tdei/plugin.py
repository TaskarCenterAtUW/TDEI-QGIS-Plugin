# -*- coding: utf-8 -*-
"""Plugin lifecycle: initGui / unload / single main window."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, List, Optional

from qgis.PyQt.QtCore import QCoreApplication, QLocale, QTranslator
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .config.settings import SettingsManager
from .core.services.container import ServiceContainer
from .core.utils.exception_handler import ExceptionHandler
from .logging.logger import configure_logging, get_logger
from .qgis.layer_context import LayerContextMenuController

if TYPE_CHECKING:
    from qgis.gui import QgsInterface

LOG = get_logger(__name__)


class TdeiPlugin:
    """QGIS plugin entry — owns lifecycle and the main window singleton."""

    def __init__(self, iface: "QgsInterface") -> None:
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions: List[QAction] = []
        self.menu = self.tr("&TDEI")
        self._translator: Optional[QTranslator] = None
        self._main_window = None
        self._container: Optional[ServiceContainer] = None
        self._layer_context: Optional[LayerContextMenuController] = None
        self._install_translator()

    def tr(self, message: str) -> str:
        return QCoreApplication.translate("TDEI", message)

    def initGui(self) -> None:
        configure_logging()
        settings = SettingsManager()
        self._container = ServiceContainer(iface=self.iface, settings=settings)
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        self.add_action(
            icon_path,
            text=self.tr("TDEI"),
            callback=self.run,
            parent=self.iface.mainWindow(),
        )
        self._layer_context = LayerContextMenuController(self._container)
        self._layer_context.attach()
        LOG.info("TDEI plugin initialized")

    def unload(self) -> None:
        if self._layer_context is not None:
            self._layer_context.detach()
            self._layer_context = None
        if self._main_window is not None:
            try:
                self._main_window.close()
            except Exception:  # noqa: BLE001 — unload must not raise
                pass
            self._main_window = None
        if self._container is not None:
            self._container.shutdown()
            self._container = None
        for action in self.actions:
            self.iface.removePluginMenu(self.tr("&TDEI"), action)
            self.iface.removeToolBarIcon(action)
        self.actions.clear()
        LOG.info("TDEI plugin unloaded")

    def run(self) -> None:
        try:
            if self._container is None:
                settings = SettingsManager()
                self._container = ServiceContainer(
                    iface=self.iface, settings=settings
                )
            if self._main_window is None:
                from .ui.main_window.main_window import MainWindow

                self._main_window = MainWindow(self._container)
                self._main_window.destroyed.connect(self._on_window_destroyed)
            self._main_window.show()
            self._main_window.raise_()
            self._main_window.activateWindow()
        except Exception as exc:  # noqa: BLE001
            ExceptionHandler.handle(
                exc,
                iface=self.iface,
                user_message=self.tr("Unable to open the TDEI plugin."),
            )

    def add_action(
        self,
        icon_path: str,
        text: str,
        callback,
        enabled_flag: bool = True,
        add_to_menu: bool = True,
        add_to_toolbar: bool = True,
        status_tip: Optional[str] = None,
        whats_this: Optional[str] = None,
        parent=None,
    ) -> QAction:
        action = QAction(QIcon(icon_path), text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)
        if status_tip:
            action.setStatusTip(status_tip)
        if whats_this:
            action.setWhatsThis(whats_this)
        if add_to_toolbar:
            self.iface.addToolBarIcon(action)
        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)
        return action

    def _on_window_destroyed(self, *_args) -> None:
        self._main_window = None

    def _install_translator(self) -> None:
        from qgis.core import QgsSettings

        locale = QgsSettings().value("locale/userLocale", QLocale().name())[0:2]
        locale_path = os.path.join(
            self.plugin_dir, "i18n", "{}.qm".format(locale)
        )
        if os.path.exists(locale_path):
            self._translator = QTranslator()
            self._translator.load(locale_path)
            QCoreApplication.installTranslator(self._translator)
