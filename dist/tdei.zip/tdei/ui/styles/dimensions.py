# -*- coding: utf-8 -*-
"""Spacing and sizing tokens."""

from __future__ import annotations

SPACING_XS = 4
SPACING_SM = 8
SPACING_MD = 12
SPACING_LG = 16
SPACING_XL = 24
SPACING_XXL = 32

RADIUS_SM = 4
RADIUS_MD = 6
RADIUS_LG = 8

SIDEBAR_WIDTH = 180
HEADER_HEIGHT = 52
CONTROL_HEIGHT = 38
ICON_SM = 16
ICON_MD = 20
ICON_LG = 24
