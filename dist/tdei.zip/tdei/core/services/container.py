# -*- coding: utf-8 -*-
"""Simple constructor-injection service locator for the plugin session."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from ...api.client import ApiClient
from ...auth.auth_manager import AuthManager
from ...auth.login_service import LoginService
from ...auth.session_manager import SessionManager
from ...auth.token_manager import TokenManager
from ...config.environment import resolve_environment
from ...config.settings import SettingsManager
from ...core.workers import WorkerPool
from ...features.datasets.service import DatasetService
from ...features.jobs.service import JobService
from ...qgis.layer_manager import LayerManager
from ...qgis.project_manager import ProjectManager
from ...ui.notifications.notification_service import NotificationService

if TYPE_CHECKING:
    from qgis.gui import QgsInterface


class ServiceContainer:
    """Wires concrete implementations for one plugin session."""

    def __init__(
        self,
        iface: "QgsInterface",
        settings: Optional[SettingsManager] = None,
    ) -> None:
        self.iface = iface
        self.settings = settings or SettingsManager()
        self.workers = WorkerPool()
        self.tokens = TokenManager(self.settings)
        self.session = SessionManager(self.tokens)
        self.api = ApiClient(
            settings=self.settings,
            token_provider=self.tokens,
            on_unauthorized=self._on_unauthorized,
        )
        self.auth = AuthManager(
            api_client=self.api,
            token_manager=self.tokens,
            session_manager=self.session,
            settings=self.settings,
        )
        self.login_service = LoginService(self.auth)
        self.notifications = NotificationService(
            iface=iface, settings=self.settings
        )
        self.layers = LayerManager(iface=iface)
        self.project = ProjectManager()
        self.datasets = DatasetService(
            api_client=self.api,
            layer_manager=self.layers,
            settings=self.settings,
        )
        self.jobs = JobService(
            api_client=self.api,
            layer_manager=self.layers,
            settings=self.settings,
        )

    def refresh_environment(self) -> None:
        self.api.reload_base_url()

    def environment(self):
        return resolve_environment(self.settings)

    def _on_unauthorized(self) -> None:
        self.auth.handle_unauthorized()

    def shutdown(self) -> None:
        self.workers.shutdown()
        self.api.close()
