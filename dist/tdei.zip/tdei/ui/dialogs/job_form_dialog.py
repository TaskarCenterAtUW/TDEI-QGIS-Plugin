# -*- coding: utf-8 -*-
"""Dynamic Qt form generated from an OpenAPI job operation."""

from __future__ import annotations

from typing import Any, Dict, List

from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ...core.models import JobDefinition, JobField


class JobFormDialog(QDialog):
    def __init__(
        self,
        job: JobDefinition,
        fields: List[JobField],
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(job.title or "TDEI Job")
        self.resize(480, 220)
        self._fields = fields
        self._widgets: Dict[str, QWidget] = {}

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(job.title or ""))
        form = QFormLayout()
        for field in fields:
            form.addRow(self._label(field), self._make_widget(field))
        layout.addLayout(form)
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def values(self) -> Dict[str, Any]:
        return {field.name: self._read(field) for field in self._fields}

    def _label(self, field: JobField) -> str:
        text = field.name.replace("_", " ")
        if field.required:
            text += " *"
        return text

    def _make_widget(self, field: JobField) -> QWidget:
        if field.format == "binary":
            widget = _FileRow(self)
            if field.value:
                widget.set_path(str(field.value))
        elif field.enum:
            widget = QComboBox(self)
            if not field.required:
                widget.addItem("", "")
            for item in field.enum:
                widget.addItem(str(item), item)
        elif field.type == "boolean":
            widget = QCheckBox(self)
        else:
            widget = QLineEdit(self)
            placeholder = field.description or ""
            if field.name == "bbox":
                placeholder = "west,south,east,north"
            elif field.type == "array":
                placeholder = placeholder or "comma-separated values"
            if placeholder:
                widget.setPlaceholderText(placeholder[:120])
        if field.value not in (None, "") and not isinstance(widget, _FileRow):
            self._set_value(widget, field, field.value)
        if field.description:
            widget.setToolTip(field.description)
        self._widgets[field.name] = widget
        return widget

    @staticmethod
    def _set_value(widget, field: JobField, value) -> None:
        if isinstance(widget, QComboBox):
            index = widget.findData(value)
            if index < 0:
                index = widget.findText(str(value))
            if index >= 0:
                widget.setCurrentIndex(index)
        elif isinstance(widget, QCheckBox):
            widget.setChecked(bool(value))
        elif isinstance(widget, QLineEdit):
            if isinstance(value, list):
                widget.setText(",".join(str(item) for item in value))
            else:
                widget.setText(str(value))

    def _read(self, field: JobField):
        widget = self._widgets[field.name]
        if isinstance(widget, _FileRow):
            return widget.path()
        if isinstance(widget, QComboBox):
            data = widget.currentData()
            return data if data is not None else widget.currentText()
        if isinstance(widget, QCheckBox):
            return widget.isChecked()
        return widget.text().strip()

    def accept(self) -> None:
        missing = [
            field.name
            for field in self._fields
            if field.required and self._read(field) in (None, "")
        ]
        if missing:
            QMessageBox.warning(
                self, "TDEI Job", "Required: {}".format(", ".join(missing))
            )
            return
        super().accept()


class _FileRow(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._edit = QLineEdit(self)
        browse = QPushButton("Browse…", self)
        browse.clicked.connect(self._browse)
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self._edit)
        row.addWidget(browse)

    def path(self) -> str:
        return self._edit.text().strip()

    def set_path(self, path: str) -> None:
        self._edit.setText(path or "")

    def _browse(self) -> None:
        chosen, _filter = QFileDialog.getOpenFileName(self, "Select file")
        if chosen:
            self._edit.setText(chosen)
