# Architecture

## Goals

Long-lived, testable QGIS plugin with clear boundaries between UI, domain,
API, auth, and QGIS integration.

## Package layout

```
tdei/
  plugin.py              # QGIS lifecycle (initGui / unload)
  config/                # QSettings + environments + migrations
  auth/                  # AuthManager, TokenManager, SessionManager
  api/                   # ApiClient, transport, v1 mappers
  core/                  # models, exceptions, workers, compatibility, DI
  features/              # datasets, jobs, osw (use-cases)
  qgis/                  # LayerManager, context menu
  ui/                    # theme, components, pages, notifications
  logging/               # redacting logger
  tests/                 # unit + integration scaffolding
  docs/                  # developer docs
  scripts/               # package / validate
```

## Dependency direction

```
UI pages → services (LoginService, DatasetService, JobService)
        → repositories/API (ApiClient)
        → transport (urllib)

UI pages → QGIS services (LayerManager) only via feature services
Auth UI  → LoginService → AuthManager → ApiClient + TokenManager
```

UI widgets contain **no** HTTP calls and **no** token handling.

## Design decisions

1. **Stdlib HTTP (`urllib`)** — avoids third-party deps in the QGIS env.
2. **Constructor DI via `ServiceContainer`** — no DI framework.
3. **Compatibility layer** — QGIS/Qt version checks live in `core/compatibility/`.
4. **Feature modules** — new capabilities add a folder under `features/` + a page.
5. **Refresh tokens** — modeled even though current TDEI `/authenticate` may only
   return an access token; wiring is isolated in `ApiClient.refresh_tokens`.
6. **Token storage** — QSettings with base64 obfuscation (not encryption).
   Documented limitation; tokens never logged or shown in UI.
7. **Legacy prototype** — previous Plugin Builder modules live in `legacy/`
   for reference and are excluded from the release ZIP.

## Main window UX

```
Login → App shell (header + sidebar + page container)
Pages: Dashboard | Datasets | Operations | Settings
```

## Threading

`Worker` / `WorkerPool` (`QRunnable` + `QThreadPool`) run network and heavy
IO off the UI thread. Results arrive via Qt signals.
