# -*- coding: utf-8 -*-
"""API v1 dataset helpers."""

from __future__ import annotations

from typing import Any, Dict, List
from urllib.parse import quote

from ...core.models import Dataset


def parse_datasets(payload: Any) -> List[Dataset]:
    items = _as_list(payload)
    datasets: List[Dataset] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        dataset_id = str(item.get("tdei_dataset_id") or "")
        metadata = item.get("metadata") or {}
        if not isinstance(metadata, dict):
            metadata = {}
        detail = metadata.get("dataset_detail") or {}
        if not isinstance(detail, dict):
            detail = {}
        name = str(detail.get("name") or "")
        datasets.append(Dataset(id=dataset_id, name=name, raw=item))
    return datasets


def osw_download_path(dataset_id: str) -> str:
    return "osw/{}?format=osw&file_version=latest".format(
        quote(str(dataset_id), safe="")
    )


def _as_list(payload: Any) -> List[Any]:
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("datasets", "data", "items", "results"):
            value = payload.get(key)
            if isinstance(value, list):
                return value
    return []
