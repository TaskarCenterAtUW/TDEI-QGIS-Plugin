# -*- coding: utf-8 -*-
from .theme import theme

__all__ = ["theme"]
