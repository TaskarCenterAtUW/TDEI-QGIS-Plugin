# -*- coding: utf-8 -*-
"""Toast + QGIS message-bar notification service."""

from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from qgis.PyQt.QtCore import QObject, QTimer, Qt
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ...core.compatibility import qgis_compat
from ..styles import colors

if TYPE_CHECKING:
    from qgis.gui import QgsInterface
    from ...config.settings import SettingsManager


class Toast(QFrame):
    def __init__(self, message: str, level: str = "info", parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Toast")
        if level == "success":
            style = "background: {}; color: #fff;".format(colors.SUCCESS)
        elif level == "error":
            style = "background: {}; color: #fff;".format(colors.ERROR)
        elif level == "warning":
            style = "background: #fff3cd; color: #856404; border: 1px solid #ffc107;"
        else:
            style = "background: {}; color: #fff;".format(colors.INFO)
        self.setStyleSheet(
            "QFrame#Toast {{ {} border-radius: 6px; }}".format(style)
        )
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        label = QLabel(message)
        label.setWordWrap(True)
        close = QPushButton("×")
        close.setFlat(True)
        close.clicked.connect(self._close)
        layout.addWidget(label, 1)
        layout.addWidget(close)

    def _close(self) -> None:
        self.hide()
        self.deleteLater()


class ToastHost(QWidget):
    """Stacks toasts in the top-right of a parent window."""

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, False)
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(8)
        self._layout.addStretch()
        self.setFixedWidth(320)
        self.raise_()

    def show_toast(self, message: str, level: str, duration_ms: int) -> None:
        toast = Toast(message, level=level, parent=self)
        self._layout.insertWidget(self._layout.count() - 1, toast)
        self._reposition()
        toast.show()
        QTimer.singleShot(duration_ms, toast._close)

    def _reposition(self) -> None:
        parent = self.parentWidget()
        if parent is None:
            return
        self.move(parent.width() - self.width() - 16, 56)
        self.resize(self.width(), parent.height() - 72)
        self.raise_()


class NotificationService(QObject):
    def __init__(
        self,
        iface: "QgsInterface",
        settings: "SettingsManager",
    ) -> None:
        super().__init__()
        self._iface = iface
        self._settings = settings
        self._host: Optional[ToastHost] = None
        self._history: List[str] = []

    def attach_host(self, window: QWidget) -> None:
        self._host = ToastHost(window)
        self._host.show()

    def success(self, message: str) -> None:
        self._emit(message, "success", qgis_compat.message_level_success())

    def info(self, message: str) -> None:
        self._emit(message, "info", qgis_compat.message_level_info())

    def warning(self, message: str) -> None:
        self._emit(message, "warning", qgis_compat.message_level_warning())

    def error(self, message: str) -> None:
        self._emit(message, "error", qgis_compat.message_level_critical())

    def _emit(self, message: str, level: str, qgis_level) -> None:
        self._history.append(message)
        if self._settings.bool("ui.show_toasts", True) and self._host is not None:
            duration = self._settings.int("ui.toast_duration_ms", 4000)
            self._host.show_toast(message, level, duration)
        else:
            self._iface.messageBar().pushMessage(
                "TDEI", message, level=qgis_level, duration=6
            )
