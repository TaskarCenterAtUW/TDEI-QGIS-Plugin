# -*- coding: utf-8 -*-
"""Plugin settings page."""

from __future__ import annotations

from typing import TYPE_CHECKING

from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from ...config.defaults import ENVIRONMENTS
from ..components import PrimaryButton
from ..dialogs.confirmation_dialog import ConfirmationDialog

if TYPE_CHECKING:
    from ...core.services.container import ServiceContainer


class SettingsPage(QWidget):
    def __init__(self, container: "ServiceContainer", parent=None) -> None:
        super().__init__(parent)
        self._container = container
        layout = QVBoxLayout(self)
        title = QLabel(self.tr("Settings"))
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        layout.addWidget(title)

        form = QFormLayout()
        self._env = QComboBox()
        for key, meta in ENVIRONMENTS.items():
            self._env.addItem(meta["label"], key)
        self._env.addItem(self.tr("Custom"), "custom")
        current = container.settings.get("environment", "development")
        index = self._env.findData(current)
        if index >= 0:
            self._env.setCurrentIndex(index)

        self._custom_url = QLineEdit(
            str(container.settings.get("custom_api_base_url", "") or "")
        )
        self._timeout = QSpinBox()
        self._timeout.setRange(5, 300)
        self._timeout.setValue(container.settings.int("request_timeout_seconds", 30))
        self._toasts = QCheckBox(self.tr("Show toast notifications"))
        self._toasts.setChecked(container.settings.bool("ui.show_toasts", True))
        self._jobs = QCheckBox(self.tr("Enable TDEI jobs"))
        self._jobs.setChecked(container.settings.feature_enabled("jobs"))

        form.addRow(self.tr("Environment"), self._env)
        form.addRow(self.tr("Custom API URL"), self._custom_url)
        form.addRow(self.tr("Request timeout (s)"), self._timeout)
        form.addRow(self._toasts)
        form.addRow(self._jobs)
        layout.addLayout(form)

        save = PrimaryButton(self.tr("Save settings"))
        save.clicked.connect(self._save)
        layout.addWidget(save)

        clear = PrimaryButton(self.tr("Clear saved session"))
        clear.clicked.connect(self._clear_session)
        layout.addWidget(clear)
        layout.addStretch()

    def _save(self) -> None:
        self._container.settings.set("environment", self._env.currentData())
        self._container.settings.set(
            "custom_api_base_url", self._custom_url.text().strip()
        )
        self._container.settings.set(
            "request_timeout_seconds", self._timeout.value()
        )
        self._container.settings.set("ui.show_toasts", self._toasts.isChecked())
        self._container.settings.set("feature.jobs", self._jobs.isChecked())
        self._container.refresh_environment()
        self._container.notifications.success(self.tr("Settings saved."))

    def _clear_session(self) -> None:
        if not ConfirmationDialog.ask(
            self,
            self.tr("Clear session"),
            self.tr("Clear stored authentication tokens and sign out?"),
            confirm_text=self.tr("Clear"),
            destructive=True,
        ):
            return
        self._container.login_service.sign_out()
        self._container.notifications.info(self.tr("Session cleared."))
