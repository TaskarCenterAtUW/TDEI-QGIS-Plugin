# Configuration

All environment-specific values are configurable. Defaults live in
`config/defaults.py`.

## Environments

| Key | API base |
|-----|----------|
| `development` | `https://api-dev.tdei.us/api/v1` |
| `staging` | `https://api-stage.tdei.us/api/v1` |
| `production` | `https://api.tdei.us/api/v1` |
| `custom` | `custom_api_base_url` setting |

Change via **Settings** in the plugin UI.

## Persisted keys (QSettings root `tdei_plugin/`)

- `environment`, `custom_api_base_url`
- `request_timeout_seconds`, `download_timeout_seconds`, `job_timeout_seconds`
- `log_level`, `ui.show_toasts`, `ui.toast_duration_ms`
- `feature.dataset_load`, `feature.jobs`, …
- `config_version` (schema migrations)
- `secure/*` — token material (obfuscated; cleared on logout)

## Feature flags

```
feature.dataset_load
feature.dataset_refresh
feature.jobs
feature.experimental_map
```

## Secrets

Never put tokens or passwords in source, `.ui` files, or layer names.
See [AUTHENTICATION.md](AUTHENTICATION.md).
