# -*- coding: utf-8 -*-
"""Login page — presentation only; auth via LoginService + workers."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING

from qgis.PyQt.QtCore import QEvent, QObject, QSize, Qt, pyqtSignal
from qgis.PyQt.QtGui import QIcon, QPainter, QPixmap
from qgis.PyQt.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ...core.exceptions import AuthenticationError, TdeiError
from ..components import PrimaryButton
from ..styles.theme import theme

if TYPE_CHECKING:
    from ...core.services.container import ServiceContainer


class _LoginBackgroundFilter(QObject):
    def __init__(self, pixmap, parent=None) -> None:
        super().__init__(parent)
        self._pixmap = pixmap

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Paint:
            painter = QPainter(obj)
            painter.setRenderHint(QPainter.SmoothPixmapTransform)
            scaled = self._pixmap.scaled(
                obj.size(),
                Qt.KeepAspectRatioByExpanding,
                Qt.SmoothTransformation,
            )
            x = (obj.width() - scaled.width()) // 2
            y = (obj.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)
            return True
        return False


class LoginPage(QWidget):
    login_succeeded = pyqtSignal()

    def __init__(self, container: "ServiceContainer", parent=None) -> None:
        super().__init__(parent)
        self._container = container
        self._build()

    def _build(self) -> None:
        root = os.path.dirname(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        )
        logo_path = os.path.join(root, "tdei_logo.png")
        bg_path = os.path.join(root, "bg_login.png")
        eye_path = os.path.join(root, "visibility.svg")
        eye_off_path = os.path.join(root, "visibility_off.svg")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        header = QWidget()
        header.setObjectName("loginHeader")
        header.setFixedHeight(56)
        header_layout = QHBoxLayout(header)
        self._header_logo = QLabel()
        self._header_logo.setObjectName("lblHeaderLogo")
        header_layout.addWidget(self._header_logo)
        header_layout.addStretch()
        outer.addWidget(header)

        self._body = QWidget()
        self._body.setObjectName("loginBody")
        body_layout = QVBoxLayout(self._body)
        body_layout.addStretch()

        card = QWidget()
        card.setObjectName("loginCard")
        card.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        card.setMaximumWidth(420)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(28, 24, 28, 24)

        self._logo = QLabel()
        self._logo.setObjectName("lblLogo")
        self._logo.setAlignment(Qt.AlignCenter)
        title = QLabel(self.tr("Welcome back"))
        title.setObjectName("lblTitle")
        title.setAlignment(Qt.AlignCenter)
        subtitle = QLabel(self.tr("Sign in to continue to TDEI"))
        subtitle.setObjectName("lblSubtitle")
        subtitle.setAlignment(Qt.AlignCenter)

        user_lbl = QLabel(self.tr("Username / Email"))
        user_lbl.setObjectName("lblUsername")
        self._username = QLineEdit()
        self._username.setObjectName("txtUsername")
        remembered = self._container.settings.get("ui.last_username", "")
        if remembered:
            self._username.setText(str(remembered))

        pass_lbl = QLabel(self.tr("Password"))
        pass_lbl.setObjectName("lblPassword")
        pass_row = QHBoxLayout()
        pass_row.setSpacing(0)
        self._password = QLineEdit()
        self._password.setObjectName("txtPassword")
        self._password.setEchoMode(QLineEdit.Password)
        self._show = QToolButton()
        self._show.setObjectName("btnShowPassword")
        self._show.setCheckable(True)
        self._eye = QIcon(eye_path)
        self._eye_off = QIcon(eye_off_path)
        self._show.setIcon(self._eye)
        self._show.setIconSize(QSize(20, 20))
        self._show.toggled.connect(self._toggle_password)
        pass_row.addWidget(self._password, 1)
        pass_row.addWidget(self._show)

        self._login_btn = PrimaryButton(self.tr("Login"))
        self._login_btn.setObjectName("btnLogin")
        self._login_btn.clicked.connect(self._on_login)
        self._username.returnPressed.connect(self._on_login)
        self._password.returnPressed.connect(self._on_login)

        self._status = QLabel("")
        self._status.setObjectName("lblStatus")
        self._status.setAlignment(Qt.AlignCenter)
        version = QLabel("V {}".format(self._plugin_version(root)))
        version.setObjectName("lblVersion")
        version.setAlignment(Qt.AlignCenter)

        for widget in (
            self._logo,
            title,
            subtitle,
            user_lbl,
            self._username,
            pass_lbl,
        ):
            card_layout.addWidget(widget)
        card_layout.addLayout(pass_row)
        card_layout.addWidget(self._login_btn)
        card_layout.addWidget(self._status)
        card_layout.addWidget(version)

        body_layout.addWidget(card, alignment=Qt.AlignHCenter)
        body_layout.addStretch()
        outer.addWidget(self._body, 1)

        if os.path.exists(logo_path):
            logo = QPixmap(logo_path)
            self._header_logo.setPixmap(
                logo.scaled(44, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )
            self._logo.setPixmap(
                logo.scaledToWidth(80, Qt.SmoothTransformation)
            )
        if os.path.exists(bg_path):
            self._bg_filter = _LoginBackgroundFilter(QPixmap(bg_path), self)
            self._body.installEventFilter(self._bg_filter)

        self.setStyleSheet(theme.login_stylesheet())

    def _toggle_password(self, visible: bool) -> None:
        if visible:
            self._password.setEchoMode(QLineEdit.Normal)
            self._show.setIcon(self._eye_off)
        else:
            self._password.setEchoMode(QLineEdit.Password)
            self._show.setIcon(self._eye)

    def _on_login(self) -> None:
        username = self._username.text().strip()
        password = self._password.text()
        if not username or not password:
            self._set_status(
                self.tr("Enter both username and password."), error=True
            )
            return
        self._login_btn.setEnabled(False)
        self._set_status(self.tr("Signing in…"))
        worker = self._container.workers.submit(
            self._container.login_service.sign_in, username, password
        )
        worker.signals.result.connect(self._on_success)
        worker.signals.error.connect(self._on_error)
        worker.signals.finished.connect(
            lambda: self._login_btn.setEnabled(True)
        )

    def _on_success(self, _user) -> None:
        self._password.clear()
        self._set_status("")
        self.login_succeeded.emit()

    def _on_error(self, exc) -> None:
        if isinstance(exc, AuthenticationError):
            message = str(exc)
        elif isinstance(exc, TdeiError):
            message = str(exc)
        else:
            message = self.tr("Unable to sign in. Please try again.")
        self._set_status(message, error=True)
        self._password.setFocus()
        self._password.selectAll()

    def _set_status(self, message: str, error: bool = False) -> None:
        self._status.setText(message)
        color = theme.error_color if error else theme.secondary_color
        self._status.setStyleSheet(
            "color: {}; font-size: 14px;".format(color)
        )

    @staticmethod
    def _plugin_version(root: str) -> str:
        metadata = os.path.join(root, "metadata.txt")
        try:
            with open(metadata) as handle:
                for line in handle:
                    if line.startswith("version="):
                        return line.split("=", 1)[1].strip()
        except OSError:
            pass
        return "1.0.0"
