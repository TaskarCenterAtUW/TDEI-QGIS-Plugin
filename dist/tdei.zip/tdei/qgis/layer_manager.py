# -*- coding: utf-8 -*-
"""QGIS layer group management for TDEI datasets."""

from __future__ import annotations

import os
import shutil
import tempfile
from typing import TYPE_CHECKING, List, Optional

from qgis.core import (
    QgsApplication,
    QgsCoordinateTransform,
    QgsProject,
    QgsRectangle,
    QgsVectorFileWriter,
    QgsVectorLayer,
)

from ..features.osw.package import zip_geojson_paths
from ..logging.logger import get_logger

if TYPE_CHECKING:
    from qgis.gui import QgsInterface

LOG = get_logger(__name__)
PARENT_GROUP_NAME = "TDEI"


class LayerManager:
    def __init__(self, iface: Optional["QgsInterface"] = None) -> None:
        self._iface = iface

    def cache_dir_for(self, dataset_id: str) -> str:
        safe = "".join(
            char if char.isalnum() or char in "-_." else "_"
            for char in str(dataset_id)
        )
        path = os.path.join(
            QgsApplication.qgisSettingsDirPath(), "tdei_osw_cache", safe
        )
        os.makedirs(path, exist_ok=True)
        return path

    def is_dataset_loaded(self, dataset_id: str) -> bool:
        return self.find_dataset_group(dataset_id) is not None

    def find_parent_group(self):
        return QgsProject.instance().layerTreeRoot().findGroup(PARENT_GROUP_NAME)

    def ensure_parent_group(self):
        parent = self.find_parent_group()
        if parent is not None:
            return parent
        parent = QgsProject.instance().layerTreeRoot().addGroup(PARENT_GROUP_NAME)
        parent.setExpanded(True)
        return parent

    def find_dataset_group(self, dataset_id: str):
        parent = self.find_parent_group()
        name = str(dataset_id)
        if parent is not None:
            group = parent.findGroup(name)
            if group is not None:
                return group
        return QgsProject.instance().layerTreeRoot().findGroup(name)

    def load_geojsons(self, dataset_id: str, geojson_paths: List[str]):
        project = QgsProject.instance()
        parent = self.ensure_parent_group()
        group = parent.addGroup(str(dataset_id))
        group.setExpanded(True)
        group.setCustomProperty("tdei_dataset_id", str(dataset_id))
        loaded = []
        try:
            for path in geojson_paths:
                layer_name = os.path.splitext(os.path.basename(path))[0]
                layer = QgsVectorLayer(path, layer_name, "ogr")
                if not layer.isValid():
                    continue
                layer.setCustomProperty("tdei_dataset_id", str(dataset_id))
                project.addMapLayer(layer, False)
                group.addLayer(layer)
                loaded.append(layer)
            if not loaded:
                raise ValueError(
                    "No valid GeoJSON layers were found in the package."
                )
        except Exception:
            for layer in loaded:
                project.removeMapLayer(layer.id())
            parent_node = group.parent()
            if parent_node is not None:
                parent_node.removeChildNode(group)
            raise
        self.zoom_to_dataset(dataset_id)
        LOG.info("Loaded %s layers for dataset %s", len(loaded), dataset_id)
        return loaded

    def zoom_to_dataset(self, dataset_id: str) -> None:
        if self._iface is None:
            return
        group = self.find_dataset_group(dataset_id)
        if group is None:
            return
        layers = []
        for child in group.findLayers():
            layer = child.layer()
            if layer is not None:
                layers.append(layer)
        if layers:
            self._zoom_to_layers(layers)

    def dataset_id_from_node(self, node) -> Optional[str]:
        if node is None:
            return None
        layer = node.layer() if hasattr(node, "layer") else None
        if layer is not None:
            value = layer.customProperty("tdei_dataset_id")
            if value:
                return str(value)
        if hasattr(node, "customProperty"):
            value = node.customProperty("tdei_dataset_id")
            if value:
                return str(value)
        parent = node.parent() if hasattr(node, "parent") else None
        if parent is not None:
            return self.dataset_id_from_node(parent)
        return None

    def layers_in_dataset(self, dataset_id: str):
        group = self.find_dataset_group(dataset_id)
        if group is None:
            return []
        layers = []
        for child in group.findLayers():
            layer = child.layer()
            if layer is not None and layer.isValid():
                layers.append(layer)
        return layers

    def prepare_osw_package_zip(self, dataset_id: str) -> str:
        layers = self._layers_for_upload(dataset_id)
        if not layers:
            raise ValueError("No GeoJSON layers found in this dataset group.")
        dest_zip = os.path.join(self.cache_dir_for(dataset_id), "osw_upload.zip")
        temp_dir = tempfile.mkdtemp(prefix="tdei_osw_export_")
        try:
            paths = []
            for layer in layers:
                path = self._geojson_path_for_layer(layer, temp_dir)
                if path:
                    paths.append(path)
            return zip_geojson_paths(paths, dest_zip)
        finally:
            shutil.rmtree(temp_dir, ignore_errors=True)

    def _layers_for_upload(self, dataset_id: str):
        group_layers = self.layers_in_dataset(dataset_id)
        selected = []
        view = self._iface.layerTreeView() if self._iface else None
        if view is not None:
            group_ids = {layer.id() for layer in group_layers}
            for layer in view.selectedLayers():
                if layer is not None and layer.id() in group_ids:
                    selected.append(layer)
        return selected or group_layers

    def _geojson_path_for_layer(self, layer, temp_dir: str) -> Optional[str]:
        source = (layer.source() or "").split("|")[0]
        if (
            source.lower().endswith((".geojson", ".json"))
            and os.path.isfile(source)
            and not layer.isModified()
        ):
            return source
        filename = (
            os.path.basename(source)
            if source
            else "{}.geojson".format(layer.name())
        )
        if not filename.lower().endswith((".geojson", ".json")):
            filename = "{}.geojson".format(layer.name())
        dest = os.path.join(temp_dir, filename)
        if os.path.exists(dest):
            stem, ext = os.path.splitext(filename)
            dest = os.path.join(
                temp_dir, "{}-{}{}".format(stem, layer.id(), ext)
            )
        self._export_layer_geojson(layer, dest)
        return dest

    @staticmethod
    def _export_layer_geojson(layer, dest_path: str) -> None:
        result = QgsVectorFileWriter.writeAsVectorFormat(
            layer, dest_path, "utf-8", layer.crs(), "GeoJSON"
        )
        error = result[0] if isinstance(result, tuple) else result
        if error != QgsVectorFileWriter.NoError:
            raise ValueError(
                'Could not export layer "{}".'.format(layer.name())
            )

    def _zoom_to_layers(self, layers) -> None:
        canvas = self._iface.mapCanvas()
        dest_crs = canvas.mapSettings().destinationCrs()
        extent = QgsRectangle()
        extent.setNull()
        project = QgsProject.instance()
        for layer in layers:
            if not layer.isValid():
                continue
            layer_extent = layer.extent()
            if layer_extent.isEmpty() or layer_extent.isNull():
                continue
            transform = QgsCoordinateTransform(layer.crs(), dest_crs, project)
            try:
                layer_extent = transform.transformBoundingBox(layer_extent)
            except Exception:  # noqa: BLE001
                pass
            if extent.isNull():
                extent = QgsRectangle(layer_extent)
            else:
                extent.combineExtentWith(layer_extent)
        if not extent.isNull() and not extent.isEmpty():
            extent.scale(1.1)
            canvas.setExtent(extent)
            canvas.refresh()
