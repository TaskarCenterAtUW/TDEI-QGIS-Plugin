# -*- coding: utf-8 -*-
"""Configuration schema migrations between plugin versions."""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable, List, Tuple

from .defaults import CONFIG_VERSION, DEFAULTS

if TYPE_CHECKING:
    from .settings import SettingsManager

Migration = Tuple[int, Callable[["SettingsManager"], None]]


class MigrationManager:
    """Apply ordered migrations until ``CONFIG_VERSION`` is reached."""

    def __init__(self, settings: "SettingsManager") -> None:
        self._settings = settings
        self._migrations: List[Migration] = [
            (1, self._migrate_to_v1),
        ]

    def ensure_current(self) -> None:
        current = self._settings.config_version()
        if current <= 0:
            current = 0
        for target, migrate in self._migrations:
            if current < target:
                migrate(self._settings)
                self._settings.set_config_version(target)
                current = target
        if current < CONFIG_VERSION:
            self._settings.set_config_version(CONFIG_VERSION)

    @staticmethod
    def _migrate_to_v1(settings: "SettingsManager") -> None:
        """Seed defaults for first production schema."""
        for key, value in DEFAULTS.items():
            if settings.get(key, None) is None:
                settings.set(key, value)
