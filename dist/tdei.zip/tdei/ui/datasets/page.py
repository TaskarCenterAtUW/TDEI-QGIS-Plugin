# -*- coding: utf-8 -*-
"""Datasets page — table + load into QGIS via DatasetService."""

from __future__ import annotations

from typing import TYPE_CHECKING, List

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ...core.exceptions import AuthenticationError, SessionExpiredError, TdeiError
from ...core.models import Dataset
from ..components import EmptyState, ErrorState, LoadingOverlay, SecondaryButton

if TYPE_CHECKING:
    from ...core.services.container import ServiceContainer


class DatasetsPage(QWidget):
    def __init__(self, container: "ServiceContainer", parent=None) -> None:
        super().__init__(parent)
        self._container = container
        self._loading_id = None
        self._build()

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        header = QHBoxLayout()
        title = QLabel(self.tr("Datasets"))
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        self._refresh = SecondaryButton(self.tr("Refresh"))
        self._refresh.clicked.connect(self.reload)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(self._refresh)
        layout.addLayout(header)

        self._status = QLabel("")
        layout.addWidget(self._status)

        self._stack = QStackedWidget()
        self._table = QTableWidget(0, 3)
        self._table.setHorizontalHeaderLabels(
            [self.tr("Dataset ID"), self.tr("Name"), self.tr("Actions")]
        )
        self._table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeToContents
        )
        self._table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.Stretch
        )
        self._table.horizontalHeader().setSectionResizeMode(
            2, QHeaderView.ResizeToContents
        )
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._empty = EmptyState(
            self.tr("No datasets found"),
            self.tr("There are currently no datasets available."),
            self.tr("Refresh"),
        )
        self._empty.retry.connect(self.reload)
        self._error = ErrorState(
            self.tr("Unable to load datasets"),
            self.tr("Please try again."),
            self.tr("Retry"),
        )
        self._error.retry.connect(self.reload)
        self._stack.addWidget(self._table)
        self._stack.addWidget(self._empty)
        self._stack.addWidget(self._error)
        layout.addWidget(self._stack, 1)

        self._overlay = LoadingOverlay(self)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if self._table.rowCount() == 0:
            self.reload()

    def reload(self) -> None:
        self._overlay.start(self.tr("Loading datasets…"))
        self._refresh.setEnabled(False)
        worker = self._container.workers.submit(
            self._container.datasets.list_datasets
        )
        worker.signals.result.connect(self._on_loaded)
        worker.signals.error.connect(self._on_load_error)
        worker.signals.finished.connect(self._on_finished)

    def _on_finished(self) -> None:
        self._overlay.stop()
        self._refresh.setEnabled(True)

    def _on_loaded(self, datasets: List[Dataset]) -> None:
        if not datasets:
            self._stack.setCurrentWidget(self._empty)
            self._status.setText(self.tr("0 datasets"))
            return
        self._stack.setCurrentWidget(self._table)
        self._table.setRowCount(0)
        self._table.setRowCount(len(datasets))
        for row, dataset in enumerate(datasets):
            self._table.setItem(row, 0, QTableWidgetItem(dataset.id))
            self._table.setItem(row, 1, QTableWidgetItem(dataset.name))
            btn = QPushButton(self.tr("View in QGIS"))
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(
                lambda _=False, did=dataset.id: self._view(did)
            )
            self._table.setCellWidget(row, 2, btn)
        count = len(datasets)
        self._status.setText(
            self.tr("1 dataset") if count == 1 else self.tr("{} datasets").format(count)
        )

    def _on_load_error(self, exc) -> None:
        if isinstance(exc, (AuthenticationError, SessionExpiredError)):
            self._container.notifications.warning(
                self.tr("Your session has expired. Please sign in again.")
            )
            return
        body = str(exc) if isinstance(exc, TdeiError) else self.tr(
            "The server could not complete the request."
        )
        self._error.set_message(self.tr("Unable to load datasets"), body)
        self._stack.setCurrentWidget(self._error)

    def _view(self, dataset_id: str) -> None:
        if self._loading_id:
            self._status.setText(self.tr("Another dataset is still loading."))
            return
        self._loading_id = dataset_id
        self._overlay.start(self.tr("Downloading {}…").format(dataset_id))
        worker = self._container.workers.submit(
            self._container.datasets.load_into_qgis, dataset_id
        )
        worker.signals.result.connect(
            lambda count, did=dataset_id: self._on_viewed(did, count)
        )
        worker.signals.error.connect(self._on_view_error)
        worker.signals.finished.connect(self._on_view_finished)

    def _on_view_finished(self) -> None:
        self._loading_id = None
        self._overlay.stop()

    def _on_viewed(self, dataset_id: str, count: int) -> None:
        if count == 0:
            self._container.notifications.info(
                self.tr("Dataset {} is already loaded.").format(dataset_id)
            )
        else:
            self._container.notifications.success(
                self.tr("Loaded {} layer(s) for {}.").format(count, dataset_id)
            )
            self._status.setText(
                self.tr("Loaded {} layer(s) in group {}.").format(
                    count, dataset_id
                )
            )

    def _on_view_error(self, exc) -> None:
        if isinstance(exc, (AuthenticationError, SessionExpiredError)):
            self._container.notifications.warning(
                self.tr("Your session has expired. Please sign in again.")
            )
            return
        self._container.notifications.error(
            str(exc) if isinstance(exc, TdeiError) else self.tr(
                "Could not load dataset."
            )
        )
