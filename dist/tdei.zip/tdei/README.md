# TDEI QGIS Plugin

Production-grade QGIS plugin for the [TDEI](https://tdei.us) OpenSidewalks platform.

## Features

- Sign in to TDEI (development / staging / production / custom API)
- Browse datasets and load OSW packages into QGIS layer groups
- Submit OpenAPI-defined TDEI jobs from the layer context menu
- Background workers (non-blocking UI), toasts, confirmations, theme

## Requirements

- QGIS **3.28+** (tested design target through 3.x)
- Python bundled with QGIS (3.9+)
- No extra pip packages required

## Install

1. Package: `python3 scripts/package_plugin.py`
2. In QGIS: Plugins → Manage and Install Plugins → Install from ZIP
3. Enable **TDEI**

Or copy this folder into your QGIS profile `python/plugins/tdei` and reload.

## Quick start

1. Open **Plugins → TDEI**
2. Sign in with your TDEI credentials
3. Open **Datasets** → **View in QGIS**
4. Right-click the dataset group → **TDEI Jobs**

## Documentation

| Doc | Purpose |
|-----|---------|
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | Layers, DI, boundaries |
| [DEVELOPMENT.md](docs/DEVELOPMENT.md) | Local setup & conventions |
| [CONFIGURATION.md](docs/CONFIGURATION.md) | Environments & settings |
| [AUTHENTICATION.md](docs/AUTHENTICATION.md) | Tokens & session UX |
| [TESTING.md](docs/TESTING.md) | Running tests |
| [UPGRADE.md](docs/UPGRADE.md) | QGIS & config migrations |

## License

GNU GPL v2 (or later), consistent with QGIS plugin norms.
