# -*- coding: utf-8 -*-
"""Default configuration values (non-secret)."""

from __future__ import annotations

from typing import Any, Dict

CONFIG_VERSION = 1

ENVIRONMENTS: Dict[str, Dict[str, Any]] = {
    "development": {
        "label": "TDEI Development",
        "api_base_url": "https://api-dev.tdei.us/api/v1",
        "auth_path": "/authenticate",
        "portal_url": "https://portal-dev.tdei.us",
    },
    "staging": {
        "label": "TDEI Staging",
        "api_base_url": "https://api-stage.tdei.us/api/v1",
        "auth_path": "/authenticate",
        "portal_url": "https://portal-stage.tdei.us",
    },
    "production": {
        "label": "TDEI Production",
        "api_base_url": "https://api.tdei.us/api/v1",
        "auth_path": "/authenticate",
        "portal_url": "https://portal.tdei.us",
    },
}

DEFAULT_ENVIRONMENT = "development"

DEFAULTS: Dict[str, Any] = {
    "config_version": CONFIG_VERSION,
    "environment": DEFAULT_ENVIRONMENT,
    "custom_api_base_url": "",
    "request_timeout_seconds": 30,
    "download_timeout_seconds": 180,
    "job_timeout_seconds": 60,
    "log_level": "INFO",
    "token_refresh_skew_seconds": 60,
    "feature.dataset_load": True,
    "feature.dataset_refresh": True,
    "feature.jobs": True,
    "feature.experimental_map": False,
    "ui.show_toasts": True,
    "ui.toast_duration_ms": 4000,
    "remember_username": True,
}
