# -*- coding: utf-8 -*-
"""Reusable UI primitives — no business logic."""

from __future__ import annotations

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from ..styles import theme
from ..styles import colors


class PrimaryButton(QPushButton):
    def __init__(self, text: str = "", parent=None) -> None:
        super().__init__(text, parent)
        self.setObjectName("PrimaryButton")
        self.setCursor(Qt.PointingHandCursor)


class SecondaryButton(QPushButton):
    def __init__(self, text: str = "", parent=None) -> None:
        super().__init__(text, parent)
        self.setObjectName("SecondaryButton")
        self.setCursor(Qt.PointingHandCursor)


class DangerButton(QPushButton):
    def __init__(self, text: str = "", parent=None) -> None:
        super().__init__(text, parent)
        self.setObjectName("DangerButton")
        self.setCursor(Qt.PointingHandCursor)


class LoadingOverlay(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("LoadingOverlay")
        layout = QVBoxLayout(self)
        self._label = QLabel("Loading…")
        self._label.setAlignment(Qt.AlignCenter)
        layout.addStretch()
        layout.addWidget(self._label)
        layout.addStretch()
        self.setStyleSheet(
            "background-color: rgba(245, 246, 250, 180); color: {};".format(
                colors.TEXT_MUTED
            )
        )
        self.hide()

    def start(self, message: str = "Loading…") -> None:
        self._label.setText(message)
        if self.parent() is not None:
            self.setGeometry(self.parent().rect())
        self.show()
        self.raise_()

    def stop(self) -> None:
        self.hide()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self.parent() is not None:
            self.setGeometry(self.parent().rect())


class EmptyState(QFrame):
    retry = pyqtSignal()

    def __init__(
        self,
        title: str = "Nothing here yet",
        body: str = "",
        action_text: str = "Refresh",
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("EmptyState")
        layout = QVBoxLayout(self)
        title_lbl = QLabel(title)
        title_lbl.setObjectName("EmptyTitle")
        body_lbl = QLabel(body)
        body_lbl.setObjectName("EmptyBody")
        body_lbl.setWordWrap(True)
        self._action = SecondaryButton(action_text)
        self._action.clicked.connect(self.retry.emit)
        layout.addWidget(title_lbl)
        layout.addWidget(body_lbl)
        layout.addWidget(self._action, alignment=Qt.AlignLeft)
        layout.addStretch()


class ErrorState(QFrame):
    retry = pyqtSignal()

    def __init__(
        self,
        title: str = "Something went wrong",
        body: str = "",
        action_text: str = "Retry",
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("ErrorState")
        layout = QVBoxLayout(self)
        self._title = QLabel(title)
        self._title.setObjectName("ErrorTitle")
        self._body = QLabel(body)
        self._body.setObjectName("ErrorBody")
        self._body.setWordWrap(True)
        self._action = PrimaryButton(action_text)
        self._action.clicked.connect(self.retry.emit)
        layout.addWidget(self._title)
        layout.addWidget(self._body)
        layout.addWidget(self._action, alignment=Qt.AlignLeft)
        layout.addStretch()

    def set_message(self, title: str, body: str) -> None:
        self._title.setText(title)
        self._body.setText(body)


class AppHeader(QWidget):
    logout_requested = pyqtSignal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("AppHeader")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 16, 0)
        self._title = QLabel("TDEI")
        self._title.setObjectName("HeaderTitle")
        self._user = QLabel("")
        self._user.setObjectName("HeaderUser")
        self._logout = QPushButton("Logout")
        self._logout.setObjectName("HeaderLogout")
        self._logout.setCursor(Qt.PointingHandCursor)
        self._logout.clicked.connect(self.logout_requested.emit)
        layout.addWidget(self._title)
        layout.addStretch()
        layout.addWidget(self._user)
        layout.addWidget(self._logout)

    def set_user(self, text: str) -> None:
        self._user.setText(text)
        self._logout.setVisible(bool(text))


class Sidebar(QWidget):
    navigate = pyqtSignal(str)

    def __init__(self, items, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Sidebar")
        self._buttons = {}
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 12, 8, 12)
        layout.setSpacing(4)
        for key, label in items:
            btn = QPushButton(label)
            btn.setProperty("class", "NavItem")
            btn.setProperty("active", "false")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked=False, k=key: self.navigate.emit(k))
            # Qt stylesheet class selector workaround
            btn.setStyleSheet("")
            btn.setObjectName("NavItem")
            btn.setProperty("active", False)
            self._buttons[key] = btn
            layout.addWidget(btn)
        layout.addStretch()

    def set_active(self, key: str) -> None:
        for name, btn in self._buttons.items():
            active = name == key
            btn.setProperty("active", active)
            btn.setStyleSheet(
                "text-align: left; padding: 10px 14px; border: none; "
                "border-radius: 6px; font-size: 14px; {}".format(
                    "background-color: {0}; color: #fff; font-weight: 600;".format(
                        theme.primary_color
                    )
                    if active
                    else "background: transparent; color: {};".format(
                        theme.text_color
                    )
                )
            )


class PageContainer(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("PageContainer")
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(16, 16, 16, 16)
        self._current = None

    def set_page(self, widget: QWidget) -> None:
        if self._current is not None:
            self._layout.removeWidget(self._current)
            self._current.hide()
        self._current = widget
        self._layout.addWidget(widget)
        widget.show()
