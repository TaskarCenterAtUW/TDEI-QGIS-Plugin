# -*- coding: utf-8 -*-
"""Main application window — shell only; pages own their workflows."""

from __future__ import annotations

from typing import TYPE_CHECKING

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QHBoxLayout,
    QMainWindow,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from ..components import AppHeader, PageContainer, Sidebar
from ..dashboard.page import DashboardPage
from ..datasets.page import DatasetsPage
from ..dialogs.confirmation_dialog import ConfirmationDialog
from ..login.page import LoginPage
from ..navigation import NavigationManager
from ..operations.page import OperationsPage
from ..settings.page import SettingsPage
from ..styles.theme import theme

if TYPE_CHECKING:
    from ...core.services.container import ServiceContainer


class MainWindow(QMainWindow):
    def __init__(self, container: "ServiceContainer") -> None:
        super().__init__(container.iface.mainWindow())
        self._container = container
        self.setObjectName("TdeiMainWindow")
        self.setWindowTitle(self.tr("TDEI"))
        self.resize(900, 640)
        self.setStyleSheet(theme.application_stylesheet())

        self._nav = NavigationManager()
        self._stack = QStackedWidget()
        self.setCentralWidget(self._stack)

        self._login = LoginPage(container)
        self._login.login_succeeded.connect(self._show_app)
        self._stack.addWidget(self._login)

        self._app_root = QWidget()
        app_layout = QVBoxLayout(self._app_root)
        app_layout.setContentsMargins(0, 0, 0, 0)
        app_layout.setSpacing(0)

        self._header = AppHeader()
        self._header.logout_requested.connect(self._logout)
        app_layout.addWidget(self._header)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        nav_items = [
            ("dashboard", self.tr("Dashboard")),
            ("datasets", self.tr("Datasets")),
            ("operations", self.tr("Operations")),
            ("settings", self.tr("Settings")),
        ]
        self._sidebar = Sidebar(nav_items)
        self._sidebar.navigate.connect(self._on_navigate)
        self._pages = PageContainer()
        body.addWidget(self._sidebar)
        body.addWidget(self._pages, 1)
        app_layout.addLayout(body, 1)

        self._stack.addWidget(self._app_root)
        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage(self.tr("Ready"))

        self._nav.register("dashboard", lambda: DashboardPage(container))
        self._nav.register("datasets", lambda: DatasetsPage(container))
        self._nav.register("operations", lambda: OperationsPage(container))
        self._nav.register("settings", lambda: SettingsPage(container))

        container.notifications.attach_host(self)
        container.auth.session_expired.connect(self._on_session_expired)

        if container.auth.try_restore() and container.auth.is_authenticated():
            user = container.session.user
            if user is None:
                from ...core.models import UserSession

                username = str(
                    container.settings.get("ui.last_username", "") or ""
                )
                container.session.mark_authenticated(
                    UserSession(username=username or "user")
                )
            self._show_app()
        else:
            self._stack.setCurrentWidget(self._login)

    def _show_app(self) -> None:
        user = self._container.session.user
        label = ""
        if user is not None:
            label = self.tr("Signed in as {}").format(user.display_name or user.username)
        self._header.set_user(label)
        self._stack.setCurrentWidget(self._app_root)
        self._on_navigate("dashboard")
        self.statusBar().showMessage(self.tr("Signed in"))

    def _on_navigate(self, key: str) -> None:
        page = self._nav.navigate(key)
        self._pages.set_page(page)
        self._sidebar.set_active(key)

    def _logout(self) -> None:
        if not ConfirmationDialog.ask(
            self,
            self.tr("Logout"),
            self.tr("Sign out of TDEI?"),
            confirm_text=self.tr("Logout"),
            destructive=True,
        ):
            return
        self._container.login_service.sign_out()
        self._header.set_user("")
        self._stack.setCurrentWidget(self._login)
        self.statusBar().showMessage(self.tr("Signed out"))
        self._container.notifications.info(self.tr("Signed out."))

    def _on_session_expired(self) -> None:
        self._header.set_user("")
        self._stack.setCurrentWidget(self._login)
        self._container.notifications.warning(
            self.tr("Your session has expired. Please sign in again.")
        )
