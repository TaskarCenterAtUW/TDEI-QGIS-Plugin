# -*- coding: utf-8 -*-
"""Typography tokens."""

from __future__ import annotations

FONT_FAMILY = "Open Sans, Segoe UI, Helvetica Neue, Arial, sans-serif"
FONT_SIZE_XS = 12
FONT_SIZE_SM = 13
FONT_SIZE_MD = 14
FONT_SIZE_LG = 16
FONT_SIZE_XL = 20
FONT_SIZE_XXL = 26
FONT_WEIGHT_LIGHT = 300
FONT_WEIGHT_REGULAR = 400
FONT_WEIGHT_SEMIBOLD = 600
FONT_WEIGHT_BOLD = 700
