# -*- coding: utf-8 -*-
"""TDEI brand colors (portal-aligned)."""

from __future__ import annotations

PRIMARY = "#32006e"
PRIMARY_HOVER = "#280058"
PRIMARY_LIGHT = "#5a2d9e"
SECONDARY = "#5f647a"
BACKGROUND = "#f5f6fa"
SURFACE = "#ffffff"
SURFACE_ALT = "#f0f1f5"
BORDER = "#dee2e6"
BORDER_STRONG = "#ced4da"
TEXT = "#212529"
TEXT_MUTED = "#5f647a"
TEXT_ON_PRIMARY = "#ffffff"
SUCCESS = "#198754"
WARNING = "#ffc107"
ERROR = "#dc3545"
INFO = "#0d6efd"
DISABLED_BG = "#cccccc"
DISABLED_TEXT = "#ffffff"
FOCUS = PRIMARY
SHADOW = "rgba(0, 0, 0, 0.12)"
LOGIN_HEADER = PRIMARY
