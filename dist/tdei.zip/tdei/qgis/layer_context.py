# -*- coding: utf-8 -*-
"""Layer-tree context menu for TDEI jobs."""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

from qgis.PyQt.QtWidgets import QDialog, QMessageBox

from ..core.compatibility.qt_compat import DialogAccepted
from ..core.exceptions import TdeiError
from ..logging.logger import get_logger
from ..ui.dialogs.job_form_dialog import JobFormDialog

if TYPE_CHECKING:
    from ..core.services.container import ServiceContainer

LOG = get_logger(__name__)


class LayerContextMenuController:
    def __init__(self, container: "ServiceContainer") -> None:
        self._container = container
        self._attached = False

    def attach(self) -> None:
        if not self._container.settings.feature_enabled("jobs"):
            return
        view = self._container.iface.layerTreeView()
        if view is None:
            return
        view.contextMenuAboutToShow.connect(self._on_menu)
        self._attached = True

    def detach(self) -> None:
        if not self._attached:
            return
        view = self._container.iface.layerTreeView()
        if view is not None:
            try:
                view.contextMenuAboutToShow.disconnect(self._on_menu)
            except TypeError:
                pass
        self._attached = False

    def _on_menu(self, menu) -> None:
        view = self._container.iface.layerTreeView()
        if view is None:
            return
        dataset_id = self._container.layers.dataset_id_from_node(
            view.currentNode()
        )
        if not dataset_id:
            return
        submenu = menu.addMenu("TDEI Jobs")
        for job in self._container.jobs.list_jobs():
            action = submenu.addAction(job.title)
            action.triggered.connect(
                lambda checked=False, current=job, did=dataset_id: self._run(
                    current, did
                )
            )

    def _run(self, job, dataset_id: str) -> None:
        if not self._container.auth.is_authenticated():
            QMessageBox.information(
                self._container.iface.mainWindow(),
                "TDEI",
                "Sign in first, then run the job from the layer menu.",
            )
            return
        fields = self._container.jobs.form_fields(job, dataset_id=dataset_id)
        for field in fields:
            if self._container.jobs.is_osw_package_field(field):
                try:
                    field.value = self._container.jobs.prepare_osw_upload(
                        dataset_id
                    )
                except (ValueError, OSError) as exc:
                    QMessageBox.warning(
                        self._container.iface.mainWindow(),
                        "TDEI Job",
                        "{}\nYou can browse to a zip file instead.".format(exc),
                    )
        dialog = JobFormDialog(
            job, fields, parent=self._container.iface.mainWindow()
        )
        if dialog.exec_() != DialogAccepted:
            return
        try:
            result = self._container.jobs.submit(
                job, fields, dialog.values(), dataset_id=dataset_id
            )
        except (TdeiError, ValueError, OSError) as exc:
            self._container.notifications.error(str(exc))
            return
        if result.job_id:
            message = "Job submitted successfully.\n\nJob ID: {}".format(
                result.job_id
            )
        elif result.location:
            message = "Job submitted successfully.\n\n{}".format(result.location)
        else:
            message = "Job submitted successfully."
        QMessageBox.information(
            self._container.iface.mainWindow(), "TDEI Job", message
        )
