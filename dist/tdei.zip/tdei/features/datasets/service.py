# -*- coding: utf-8 -*-
"""Dataset use cases."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, List

from ...api.v1.datasets import parse_datasets
from ...core.models import Dataset
from ...features.osw.package import assert_zip_bytes, unpack_osw_package
from ...logging.logger import get_logger
from urllib.parse import quote

if TYPE_CHECKING:
    from ...api.client import ApiClient
    from ...config.settings import SettingsManager
    from ...qgis.layer_manager import LayerManager

LOG = get_logger(__name__)


class DatasetService:
    def __init__(
        self,
        api_client: "ApiClient",
        layer_manager: "LayerManager",
        settings: "SettingsManager",
    ) -> None:
        self._api = api_client
        self._layers = layer_manager
        self._settings = settings
        self._cache: List[Dataset] = []

    def list_datasets(self, *, use_cache: bool = False) -> List[Dataset]:
        if use_cache and self._cache:
            return list(self._cache)
        payload = self._api.get("datasets")
        datasets = parse_datasets(payload)
        self._cache = datasets
        LOG.info("Loaded %s datasets", len(datasets))
        return list(datasets)

    def invalidate_cache(self) -> None:
        self._cache = []

    def load_into_qgis(self, dataset_id: str) -> int:
        if self._layers.is_dataset_loaded(dataset_id):
            self._layers.zoom_to_dataset(dataset_id)
            return 0
        cache_dir = self._layers.cache_dir_for(dataset_id)
        zip_path = os.path.join(cache_dir, "package.zip")
        data = self._api.download_bytes(
            "osw/{}".format(quote(str(dataset_id), safe="")),
            query="?format=osw&file_version=latest",
        )
        assert_zip_bytes(data)
        parent = os.path.dirname(zip_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        with open(zip_path, "wb") as handle:
            handle.write(data)
        geojsons = unpack_osw_package(
            zip_path, os.path.join(cache_dir, "extracted")
        )
        layers = self._layers.load_geojsons(dataset_id, geojsons)
        return len(layers)
