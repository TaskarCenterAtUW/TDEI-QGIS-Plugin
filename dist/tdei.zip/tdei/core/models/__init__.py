# -*- coding: utf-8 -*-
"""Domain models — independent of Qt and QGIS UI."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class AuthState(str, Enum):
    ANONYMOUS = "anonymous"
    AUTHENTICATED = "authenticated"
    EXPIRED = "expired"
    REFRESHING = "refreshing"


@dataclass
class UserSession:
    username: str
    display_name: str = ""


@dataclass
class TokenPair:
    access_token: str
    refresh_token: Optional[str] = None
    expires_at: Optional[float] = None  # epoch seconds
    token_type: str = "Bearer"


@dataclass
class Dataset:
    id: str
    name: str
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def display_name(self) -> str:
        return self.name or self.id


@dataclass
class JobDefinition:
    title: str
    path: str
    method: str
    operation: Dict[str, Any]


@dataclass
class JobField:
    name: str
    location: str
    required: bool
    type: str = "string"
    format: Optional[str] = None
    enum: Optional[List[Any]] = None
    description: str = ""
    value: Any = ""


@dataclass
class JobSubmissionResult:
    job_id: str = ""
    location: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AppState:
    auth_state: AuthState = AuthState.ANONYMOUS
    current_user: Optional[UserSession] = None
    selected_dataset_id: Optional[str] = None
    loading: bool = False
